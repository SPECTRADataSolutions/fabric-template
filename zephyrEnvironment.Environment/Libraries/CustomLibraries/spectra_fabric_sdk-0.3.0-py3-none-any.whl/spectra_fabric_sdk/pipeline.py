"""
SPECTRA Fabric SDK - Pipeline Execution Context

Detects and exposes Fabric pipeline execution context:
- Pipeline vs interactive vs local execution
- Operation type and activity tracking
- Runtime mode detection

Part of the SPECTRA Seven-Stage Data Platform.
"""

from typing import Optional


class Pipeline:
    """Fabric pipeline execution context.
    
    Detects whether notebook is running in:
    - Pipeline mode (scheduled/triggered execution)
    - Interactive mode (ad-hoc cell execution in Fabric UI)
    - Local mode (future: Cursor/local testing)
    
    All properties read from Spark configuration at runtime.
    
    Example:
        >>> pipeline = Pipeline(spark)
        >>> if pipeline.is_active:
        ...     log.info("Running in production pipeline")
        >>> else:
        ...     log.info("Running in interactive development mode")
    """
    
    def __init__(self, spark):
        """Initialize Pipeline context.
        
        Args:
            spark: Active SparkSession instance
        """
        self._spark = spark
    
    @property
    def is_active(self) -> bool:
        """Is this notebook running in a pipeline?
        
        Returns:
            True if running in pipeline, False if interactive/local
        """
        return self.operation_type != "SessionCreation"
    
    @property
    def is_interactive(self) -> bool:
        """Is this notebook running interactively in Fabric?
        
        Interactive = Running cells manually in Fabric UI.
        
        Returns:
            True if interactive, False if pipeline/local
        """
        return self.operation_type == "SessionCreation"
    
    @property
    def is_local(self) -> bool:
        """Is this notebook running locally? (Future feature)
        
        Local = Running in Cursor/VSCode for testing.
        
        Returns:
            True if local, False if Fabric (interactive or pipeline)
        """
        # Detect local by absence of workspace_id
        workspace_id = self._spark.conf.get("trident.workspace.id", "")
        return workspace_id == ""
    
    @property
    def operation_type(self) -> str:
        """Fabric operation type.
        
        Values:
            - "SessionCreation" = Interactive mode
            - "PipelineRun" = Pipeline execution
            - Other values = Various pipeline/batch operations
            - "Unknown" = Not in Fabric (local testing)
        
        Returns:
            Operation type string
        """
        return self._spark.conf.get("trident.operation.type", "Unknown")
    
    @property
    def activity_id(self) -> str:
        """Unique ID for this pipeline activity.
        
        Used for tracking and logging pipeline executions.
        
        Returns:
            Activity UUID or empty string if not in pipeline
        """
        return self._spark.conf.get("trident.activity.id", "")
    
    @property
    def moniker_id(self) -> str:
        """Fabric moniker ID.
        
        Internal Fabric tracking identifier.
        
        Returns:
            Moniker UUID or empty string
        """
        return self._spark.conf.get("trident.moniker.id", "")
    
    def to_dict(self) -> dict:
        """Export all pipeline context as dictionary.
        
        Useful for logging and debugging.
        
        Returns:
            Dictionary with all pipeline properties
        """
        return {
            "is_active": self.is_active,
            "is_interactive": self.is_interactive,
            "is_local": self.is_local,
            "operation_type": self.operation_type,
            "activity_id": self.activity_id,
            "moniker_id": self.moniker_id,
        }
    
    def __repr__(self) -> str:
        """String representation for debugging."""
        mode = "pipeline" if self.is_active else ("local" if self.is_local else "interactive")
        return f"Pipeline(mode={mode}, operation_type={self.operation_type})"

