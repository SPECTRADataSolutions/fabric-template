"""
SPECTRA Fabric SDK - Environment Infrastructure Context

Exposes Fabric workspace, lakehouse, and tenant infrastructure context.
All values read from Spark configuration at runtime.

Part of the SPECTRA Seven-Stage Data Platform.
"""

from typing import Optional


class Environment:
    """Fabric workspace and lakehouse environment context.
    
    Provides runtime access to:
    - Workspace ID and name
    - Lakehouse ID and name
    - Tenant ID and capacity ID
    - OneLake paths and filesystem info
    
    All values are read from Spark configuration (trident.* properties)
    provided by Fabric at runtime.
    
    Example:
        >>> env = Environment(spark)
        >>> log.info(f"Workspace: {env.workspace_id}")
        >>> log.info(f"Lakehouse: {env.lakehouse_name}")
        >>> log.info(f"OneLake: {env.onelake_root}")
    """
    
    def __init__(self, spark):
        """Initialize Environment context.
        
        Args:
            spark: Active SparkSession instance
        """
        self._spark = spark
    
    # ══════════════════════════════════════════════════════════════════════
    # Workspace Properties
    # ══════════════════════════════════════════════════════════════════════
    
    @property
    def workspace_id(self) -> str:
        """Fabric workspace UUID.
        
        Returns:
            Workspace UUID or empty string if not in Fabric
        """
        return self._spark.conf.get("trident.workspace.id", "")
    
    @property
    def workspace_name(self) -> str:
        """Fabric workspace display name.
        
        Note: Not always available from Spark config.
        May need to read from Variable Library if needed.
        
        Returns:
            Workspace name or empty string
        """
        return self._spark.conf.get("trident.workspace.name", "")
    
    @property
    def artifact_workspace_id(self) -> str:
        """Artifact's workspace ID (may differ from workspace_id).
        
        Returns:
            Artifact workspace UUID
        """
        return self._spark.conf.get("trident.artifact.workspace.id", "")
    
    # ══════════════════════════════════════════════════════════════════════
    # Lakehouse Properties
    # ══════════════════════════════════════════════════════════════════════
    
    @property
    def lakehouse_id(self) -> str:
        """Attached lakehouse UUID.
        
        Returns:
            Lakehouse UUID or empty string
        """
        return self._spark.conf.get("trident.lakehouse.id", "")
    
    @property
    def lakehouse_name(self) -> str:
        """Attached lakehouse display name.
        
        Returns:
            Lakehouse name or empty string
        """
        return self._spark.conf.get("trident.lakehouse.name", "")
    
    @property
    def default_lakehouse_id(self) -> str:
        """Default lakehouse ID (extracted from homeDir).
        
        May differ from attached lakehouse_id.
        
        Returns:
            Default lakehouse UUID
        """
        home_dir = self._spark.conf.get("fs.homeDir", "")
        if home_dir:
            # Extract UUID from path like /1d58e7f6-c136-432d-abed-57db0f6603af
            return home_dir.strip("/").split("/")[-1]
        return ""
    
    # ══════════════════════════════════════════════════════════════════════
    # Tenant & Capacity
    # ══════════════════════════════════════════════════════════════════════
    
    @property
    def tenant_id(self) -> str:
        """Azure tenant UUID.
        
        Returns:
            Tenant UUID or empty string
        """
        return self._spark.conf.get("trident.tenant.id", "")
    
    @property
    def capacity_id(self) -> str:
        """Fabric capacity UUID.
        
        Returns:
            Capacity UUID or empty string
        """
        return self._spark.conf.get("trident.capacity.id", "")
    
    # ══════════════════════════════════════════════════════════════════════
    # OneLake & Filesystem
    # ══════════════════════════════════════════════════════════════════════
    
    @property
    def onelake_root(self) -> str:
        """OneLake root path (abfss:// URL).
        
        Example: abfss://16490dde-...@onelake.dfs.fabric.microsoft.com/
        
        Returns:
            OneLake ABFSS root URL
        """
        return self._spark.conf.get("fs.defaultFS", "")
    
    @property
    def onelake_home(self) -> str:
        """OneLake home directory path.
        
        Example: /1d58e7f6-c136-432d-abed-57db0f6603af
        
        Returns:
            Home directory path
        """
        return self._spark.conf.get("fs.homeDir", "")
    
    # ══════════════════════════════════════════════════════════════════════
    # Artifact Info
    # ══════════════════════════════════════════════════════════════════════
    
    @property
    def artifact_id(self) -> str:
        """Current artifact (notebook/pipeline) UUID.
        
        Returns:
            Artifact UUID
        """
        return self._spark.conf.get("trident.artifact.id", "")
    
    @property
    def artifact_type(self) -> str:
        """Current artifact type.
        
        Example: "SynapseNotebook"
        
        Returns:
            Artifact type string
        """
        return self._spark.conf.get("trident.artifact.type", "")
    
    # ══════════════════════════════════════════════════════════════════════
    # Helpers
    # ══════════════════════════════════════════════════════════════════════
    
    def to_dict(self) -> dict:
        """Export all environment context as dictionary.
        
        Useful for logging, debugging, and configuration tracking.
        
        Returns:
            Dictionary with all environment properties
        """
        return {
            "workspace_id": self.workspace_id,
            "workspace_name": self.workspace_name,
            "lakehouse_id": self.lakehouse_id,
            "lakehouse_name": self.lakehouse_name,
            "default_lakehouse_id": self.default_lakehouse_id,
            "tenant_id": self.tenant_id,
            "capacity_id": self.capacity_id,
            "onelake_root": self.onelake_root,
            "onelake_home": self.onelake_home,
            "artifact_id": self.artifact_id,
            "artifact_type": self.artifact_type,
        }
    
    def __repr__(self) -> str:
        """String representation for debugging."""
        return (
            f"Environment(workspace={self.workspace_id[:8]}..., "
            f"lakehouse={self.lakehouse_name})"
        )

