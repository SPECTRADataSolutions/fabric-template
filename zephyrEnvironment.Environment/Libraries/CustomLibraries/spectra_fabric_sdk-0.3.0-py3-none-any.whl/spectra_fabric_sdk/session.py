"""NotebookSession - The Seven-Stage geometric pattern for SPECTRA notebooks."""

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from .pipeline import Pipeline
from .environment import Environment
from .variables import VariableLibrary
from .delta import DeltaTable
from .logger import SPECTRALogger


class NotebookSession:
    """
    Manages complete notebook lifecycle with geometric 7-stage pattern.

    Each stage maps to one method call:
        Stage 2: load_context()
        Stage 3: initialize()
        Stage 4: [EXECUTE - custom work]
        Stage 5: validate()
        Stage 6: record()
        Stage 7: complete()

    Usage:
        >>> session = NotebookSession("zephyrVariables")
        >>> session.load_context(bootstrap=True, debug=False)
        >>> log = session.initialize()
        >>> # ... custom Execute stage work ...
        >>> session.validate()
        >>> session.record()
        >>> session.complete()
    """

    def __init__(self, variable_library_name: str):
        """
        Create notebook session.

        Args:
            variable_library_name: Name of Fabric Variable Library (e.g., "zephyrVariables")
                                  Each source has its own library with clean variable names.
        """
        self.variable_library_name = variable_library_name
        self.ctx: Dict[str, Any] = {}
        self.params: Dict[str, Any] = {}
        self.log: Optional[logging.Logger] = None
        self.debug: bool = False
        self.start_time: Optional[datetime] = None
        self.result: Dict[str, Any] = {"status": "Success", "capabilities": []}
        
        # Specialized components (initialized in load_context)
        self.pipeline: Optional[Pipeline] = None
        self.environment: Optional[Environment] = None
        self.variables: Optional[VariableLibrary] = None
        self.delta: Optional[DeltaTable] = None

    # ══ STAGE 2: CONTEXT ════════════════════════════════════════════════════

    def load_context(
        self,
        bootstrap: bool = False,
        backfill: bool = False,
        preview: bool = False,
        debug: bool = False,
        **kwargs,
    ) -> None:
        """
        Load Fabric context + Variable Library + validate parameters.

        Performs:
            - Load Fabric infrastructure (workspace_id, lakehouse_id)
            - Load Variable Library (source config)
            - Detect execution mode (pipeline vs interactive)
            - Validate parameters (contradictions, auto-enables)

        Args:
            bootstrap: Bootstrap mode
            backfill: Backfill mode
            preview: Preview mode
            debug: Debug mode
            **kwargs: Additional parameters

        Updates:
            self.ctx: Complete context dictionary
            self.params: Validated parameters
        """
        try:
            from notebookutils import mssparkutils
        except ImportError:
            mssparkutils = None  # Running locally
        
        from pyspark.sql import SparkSession

        spark = SparkSession.builder.getOrCreate()

        # Initialize specialized components
        self.pipeline = Pipeline(spark)
        self.environment = Environment(spark)
        self.variables = VariableLibrary(self.variable_library_name, mssparkutils)
        self.delta = DeltaTable(spark, self.log)  # Will update logger later
        
        # Convenience aliases
        workspace_id = self.environment.workspace_id
        lakehouse_id = self.environment.lakehouse_id
        lakehouse_name = self.environment.lakehouse_name
        operation_type = self.pipeline.operation_type
        tenant_id = self.environment.tenant_id

        # Read from Variable Library (clean names - library provides namespace)
        source_system = self.variables.get("SOURCE_SYSTEM", required=True)
        source_name = self.variables.get("SOURCE_NAME", required=True)
        stage = self.variables.get("STAGE", required=True)
        notebook_name = self.variables.get("NOTEBOOK_NAME", required=True)

        # Get API configuration (clean names)
        base_url = self.variables.get("BASE_URL")
        base_path = self.variables.get("BASE_PATH")
        full_url = f"{base_url}{base_path}" if base_url and base_path else base_url

        # Store complete context
        self.ctx = {
            # Fabric infrastructure
            "workspace_id": workspace_id,
            "lakehouse_id": lakehouse_id,
            "lakehouse_name": lakehouse_name,
            "tenant_id": tenant_id,
            # Source system
            "source_system": source_system,
            "source_name": source_name,
            "stage": stage,
            "notebook_name": notebook_name,
            "base_url": base_url,
            "base_path": base_path,
            "full_url": full_url,
            # Execution context (using Pipeline class)
            "operation_type": self.pipeline.operation_type,
            "in_pipeline": self.pipeline.is_active,
            "in_interactive": self.pipeline.is_interactive,
            "in_local": self.pipeline.is_local,
        }

        # Validate parameters
        self.params = self._validate_parameters(
            bootstrap, backfill, preview, debug, **kwargs
        )

        # Print context
        print("📍 Fabric Infrastructure Context:")
        print(f"   • workspace_id: {workspace_id}")
        print(f"   • lakehouse_id: {lakehouse_id}")
        print(f"   • lakehouse_name: {lakehouse_name}")
        print()
        print("📡 Source System Configuration:")
        print(f"   • source_system: {source_system}")
        print(f"   • source_name: {source_name}")
        print(f"   • stage: {stage}")
        print(f"   • notebook_name: {notebook_name}")
        print(f"   • base_url: {base_url}")
        print()
        print("🔍 Execution Context:")
        print(f"   • operation_type: {operation_type}")
        print(f"   • in_pipeline: {self.ctx['in_pipeline']}")
        print(f"   • in_interactive: {self.ctx['in_interactive']}")

    def _validate_parameters(
        self, bootstrap: bool, backfill: bool, preview: bool, debug: bool, **kwargs
    ) -> Dict[str, Any]:
        """Validate and resolve parameter contradictions."""
        params = {
            "bootstrap": bootstrap,
            "backfill": backfill,
            "preview": preview,
            "debug": debug,
            **kwargs,
        }

        # Standard rules
        if params["bootstrap"] and params["backfill"]:
            params["backfill"] = False

        if params["bootstrap"] and not params["preview"]:
            params["preview"] = True

        # Smart debug in interactive mode
        if self.ctx["in_interactive"] and not params["debug"]:
            params["debug"] = True

        return params

    # ══ STAGE 3: INITIALIZE ═════════════════════════════════════════════════

    def initialize(self) -> logging.Logger:
        """
        Initialize logger and start execution timer.

        Returns:
            logging.Logger: Configured logger

        Updates:
            self.log: Logger instance
            self.debug: Resolved debug flag
            self.start_time: Execution start timestamp
        """
        # Determine log level (smart debug in interactive mode)
        self.debug = self.params["debug"]
        level = SPECTRALogger.get_default_level(
            is_interactive=self.ctx["in_interactive"],
            debug_override=self.debug
        )
        
        # Create SPECTRA-grade logger
        log = SPECTRALogger.create(
            name=self.ctx['notebook_name'],
            level=level,
            notebook_name=self.ctx['notebook_name'],
            workspace_id=self.ctx['workspace_id'],
            stage=self.ctx['stage']
        )

        # Update DeltaTable logger
        if self.delta:
            self.delta._log = log

        # Start timer
        self.start_time = datetime.utcnow()

        # Log startup banner
        log.info("=" * 80)
        log.info(f"🚀 {self.ctx['notebook_name']} | {self.ctx['stage']}")
        log.info("=" * 80)
        log.info(f"Source: {self.ctx['source_name']} ({self.ctx['source_system']})")
        log.info(
            f"Workspace: {self.ctx['lakehouse_name']} ({self.ctx['workspace_id']})"
        )
        log.info(f"Mode: {'Interactive' if self.ctx['in_interactive'] else 'Pipeline'}")
        log.info(
            f"Parameters: bootstrap={self.params['bootstrap']}, "
            f"backfill={self.params['backfill']}, "
            f"preview={self.params['preview']}, "
            f"debug={self.params['debug']}"
        )
        log.info("=" * 80)

        # Store logger
        self.log = log
        return log

    # ══ STAGE 4: EXECUTE ════════════════════════════════════════════════════
    # (Custom work in notebook - session provides helpers)

    def add_capability(self, capability: str, **metadata: Any) -> None:
        """
        Add capability to result.

        Args:
            capability: Capability name (e.g., "authVerified")
            **metadata: Additional metadata to store with capability
        """
        self.result["capabilities"].append(capability)
        if metadata:
            self.result[capability] = metadata
        self.log.debug(f"  Added capability: {capability}")

    def mark_failed(self, error_msg: str) -> None:
        """
        Mark execution as failed.

        Args:
            error_msg: Error message
        """
        self.result["status"] = "Failed"
        self.result["error"] = error_msg
        self.log.error(f"❌ {error_msg}")

    def register_table(self, table_name: str, path: str) -> None:
        """
        Register Delta table in Spark metastore.

        Delegates to DeltaTable class.

        Args:
            table_name: Fully qualified table name (e.g., "source.endpoints")
            path: Delta table path (e.g., "Tables/source/endpoints")
        """
        self.delta.register(table_name, path)
        from pyspark.sql import SparkSession

        spark = SparkSession.builder.getOrCreate()
        spark.sql(
            f"CREATE TABLE IF NOT EXISTS {table_name} USING DELTA LOCATION '{path}'"
        )
        self.log.info(f"  📋 Registered: {table_name}")

    def get_credential(self, var_name: str) -> str:
        """
        Get credential from Variable Library.

        Args:
            var_name: Variable name (e.g., "DXC_ZEPHYR_API_TOKEN")

        Returns:
            str: Credential value
        """
        return getattr(self.ctx["vars"], var_name)

    def create_config_tables(self) -> None:
        """Create standard source configuration tables (_source, _credentials, _config)."""
        from pyspark.sql import SparkSession
        from pyspark.sql.types import (
            BooleanType,
            StringType,
            StructField,
            StructType,
            TimestampType,
        )

        spark = SparkSession.builder.getOrCreate()

        self.log.info("🔧 Creating configuration tables...")

        # _source table
        source_data = [
            {
                "sourceSystem": self.ctx["source_system"],
                "baseUrl": self.ctx["full_url"],
                "isEnabled": True,
            }
        ]
        df_source = spark.createDataFrame(source_data)
        df_source.write.mode("overwrite").format("delta").option(
            "overwriteSchema", "true"
        ).save("Tables/source/_source")
        self.register_table("source._source", "Tables/source/_source")

        # _credentials table (empty schema)
        credential_schema = StructType(
            [
                StructField("workspaceName", StringType(), True),
                StructField("sourceSystem", StringType(), True),
                StructField("key", StringType(), True),
                StructField("value", StringType(), True),
                StructField("isEnabled", BooleanType(), True),
                StructField("expiresAt", TimestampType(), True),
            ]
        )
        df_credentials = spark.createDataFrame([], credential_schema)
        df_credentials.write.mode("overwrite").format("delta").option(
            "overwriteSchema", "true"
        ).save("Tables/source/_credentials")
        self.register_table("source._credentials", "Tables/source/_credentials")

        # _config table
        config_data = [
            {
                "workspaceName": self.ctx["workspace_id"],
                "workspaceId": self.ctx["workspace_id"],
                "lakehouseId": self.ctx["lakehouse_id"],
                "semanticModelId": None,
            }
        ]
        df_config = spark.createDataFrame(config_data)
        df_config.write.mode("overwrite").format("delta").option(
            "overwriteSchema", "true"
        ).save("Tables/source/_config")
        self.register_table("source._config", "Tables/source/_config")

        self.log.info("✅ Configuration tables created")

    # ══ STAGE 5: VALIDATE ═══════════════════════════════════════════════════

    def validate(self, expected_capabilities: Optional[list] = None) -> None:
        """
        Validate execution result.

        Checks:
            - result["status"] == "Success"
            - Expected capabilities present (if provided)

        Args:
            expected_capabilities: List of expected capabilities

        Raises:
            RuntimeError: If validation fails
        """
        self.log.info("🔍 Validating execution result...")

        # Check status
        if self.result.get("status") != "Success":
            error = self.result.get("error", "Unknown error")
            self.log.error(f"❌ Validation failed: {error}")
            raise RuntimeError(f"Execution validation failed: {error}")

        # Check capabilities
        if expected_capabilities:
            actual = self.result.get("capabilities", [])
            missing = [cap for cap in expected_capabilities if cap not in actual]
            if missing:
                self.log.warning(f"⚠️ Missing capabilities: {missing}")

        capabilities_count = len(self.result.get("capabilities", []))
        self.log.info(f"✅ Validation passed ({capabilities_count} capabilities)")

    # ══ STAGE 6: RECORD ═════════════════════════════════════════════════════

    def record(self) -> None:
        """
        Record stage activity and credentials to Delta.

        Writes:
            - Stage activity log (Tables/log/{stage}log)
            - Validated credentials (Tables/source/_credentials)
        """
        self.log.info("📝 Recording stage activity...")

        # Log stage activity
        self._log_stage_activity()

        # Store credentials (if Source stage)
        if self.ctx["stage"] == "source":
            self._write_credentials()

        self.log.info("✅ Stage activity recorded")

    def _log_stage_activity(self) -> None:
        """Write stage activity to Delta log table."""
        from pyspark.sql import SparkSession

        spark = SparkSession.builder.getOrCreate()

        # Enrich result with standard fields
        enriched = {
            "stage": self.ctx["stage"],
            "sourceSystem": self.ctx["source_system"],
            "notebookName": self.ctx["notebook_name"],
            "status": self.result.get("status"),
            "loggedAt": datetime.utcnow(),
            "capabilities": str(self.result.get("capabilities", [])),
            **self.result,
        }

        # Remove None values
        enriched = {k: v for k, v in enriched.items() if v is not None}

        # Write to log table
        log_table_path = f"Tables/log/{self.ctx['stage']}log"
        df_log = spark.createDataFrame([enriched])
        df_log.write.mode("append").format("delta").save(log_table_path)

        self.log.debug(f"  📋 Logged to {log_table_path}")

    def _write_credentials(self) -> None:
        """Write validated credentials to Delta (Source stage only)."""
        from pyspark.sql import SparkSession

        spark = SparkSession.builder.getOrCreate()

        # Get API token
        token_var = f"DXC_{self.ctx['source_system'].upper()}_API_TOKEN"
        api_token = getattr(self.ctx["vars"], token_var, None)

        if not api_token:
            self.log.warning(f"⚠️ No API token found ({token_var})")
            return

        # Set far-future expiry
        expires_at = datetime(2099, 12, 31, 23, 59, 59, tzinfo=timezone.utc)

        credential_data = [
            {
                "workspaceName": self.ctx["workspace_id"],
                "sourceSystem": self.ctx["source_system"],
                "key": "apiToken",
                "value": api_token,
                "isEnabled": True,
                "expiresAt": expires_at,
            }
        ]

        df_creds = spark.createDataFrame(credential_data)
        df_creds.write.mode("append").format("delta").save("Tables/source/_credentials")

        self.log.debug("  💾 Credentials stored")

    # ══ STAGE 7: COMPLETE ═══════════════════════════════════════════════════

    def complete(self, final_result: Optional[Dict[str, Any]] = None) -> None:
        """
        Log completion summary and finalize session.

        Args:
            final_result: Optional final result to merge with self.result

        Prints:
            Completion banner with duration, status, capabilities
        """
        if final_result:
            self.result.update(final_result)

        end_time = datetime.utcnow()
        duration = (end_time - self.start_time).total_seconds()

        self.log.info("=" * 80)
        self.log.info(f"✅ {self.ctx['notebook_name']} Complete")
        self.log.info(f"Duration: {duration:.2f}s")
        self.log.info(f"Status: {self.result['status']}")
        self.log.info(f"Capabilities: {self.result.get('capabilities', [])}")
        self.log.info("=" * 80)

    # ══ CONVENIENCE PROPERTIES ══════════════════════════════════════════════

    @property
    def workspace_id(self) -> str:
        """Get workspace ID from context."""
        return self.ctx.get("workspace_id")

    @property
    def lakehouse_id(self) -> str:
        """Get lakehouse ID from context."""
        return self.ctx.get("lakehouse_id")

    @property
    def source_system(self) -> str:
        """Get source system key from context."""
        return self.ctx.get("source_system")

    @property
    def source_name(self) -> str:
        """Get source system display name from context."""
        return self.ctx.get("source_name")

    @property
    def stage(self) -> str:
        """Get SPECTRA stage from context."""
        return self.ctx.get("stage")

    @property
    def notebook_name(self) -> str:
        """Get notebook name from context."""
        return self.ctx.get("notebook_name")

    @property
    def base_url(self) -> str:
        """Get API base URL from context."""
        return self.ctx.get("full_url")

    @property
    def api_token(self) -> str:
        """Get API token from Variable Library."""
        token_var = f"DXC_{self.source_system.upper()}_API_TOKEN"
        return getattr(self.ctx["vars"], token_var)

    @property
    def in_interactive(self) -> bool:
        """Check if running in interactive Fabric session."""
        return self.ctx.get("in_interactive", False)

    @property
    def in_pipeline(self) -> bool:
        """Check if running in pipeline mode."""
        return self.ctx.get("in_pipeline", False)
