"""
SPECTRA Fabric SDK - Variable Library Accessor

Type-safe accessor for Fabric Variable Library with fallback support.

Part of the SPECTRA Seven-Stage Data Platform.
"""

from typing import Optional, Any


class VariableLibrary:
    """Fabric Variable Library accessor.
    
    Provides type-safe access to Fabric Variable Library with:
    - Automatic NotebookUtils (mssparkutils) integration
    - Fallback to environment variables
    - Required vs optional variable handling
    - Type coercion (bool, int, float)
    - Secret variable support (never logged)
    
    Example:
        >>> variables = VariableLibrary("zephyrVariables", mssparkutils)
        >>> 
        >>> # Get required secret
        >>> api_token = variables.get_secret("API_TOKEN")
        >>> 
        >>> # Get optional config with default
        >>> base_url = variables.get("BASE_URL", default="https://api.example.com")
        >>> 
        >>> # Get boolean flag
        >>> enabled = variables.get_bool("FEATURE_ENABLED", default=False)
        >>> 
        >>> # Get integer
        >>> timeout = variables.get_int("TIMEOUT_SECONDS", default=30)
    """
    
    def __init__(self, library_name: str, mssparkutils=None):
        """Initialize Variable Library accessor.
        
        Args:
            library_name: Name of Fabric Variable Library
            mssparkutils: Fabric NotebookUtils instance (optional, deprecated)
        """
        self.library_name = library_name
        self._utils = mssparkutils
        self._library_obj = None  # Cached library object
    
    def get(
        self,
        key: str,
        default: Optional[str] = None,
        required: bool = False
    ) -> Optional[str]:
        """Get variable from library.
        
        Attempts to:
        1. Read from Fabric Variable Library (if mssparkutils available)
        2. Fall back to environment variables
        3. Return default value if not found
        4. Raise error if required=True and not found
        
        Args:
            key: Variable name
            default: Default value if not found
            required: Raise error if missing?
        
        Returns:
            Variable value as string, or None if not found
        
        Raises:
            ValueError: If required=True and variable not found
        
        Example:
            >>> base_url = variables.get("BASE_URL", required=True)
            >>> timeout = variables.get("TIMEOUT", default="30")
        """
        value = None
        
        # Try Fabric Variable Library first (if library_name provided)
        if self.library_name:
            try:
                # Lazy load library object
                if self._library_obj is None:
                    from notebookutils import variableLibrary
                    self._library_obj = variableLibrary.getLibrary(self.library_name)
                
                # Access variable as attribute
                value = getattr(self._library_obj, key, None)
            except Exception:
                pass  # Variable not found or library not accessible, try fallback
        
        # Fallback to environment variables (or only source if no library)
        if value is None:
            import os
            value = os.environ.get(key)
        
        # Handle not found
        if value is None:
            if required:
                if self.library_name:
                    raise ValueError(
                        f"Required variable '{key}' not found in Variable Library "
                        f"'{self.library_name}' or Fabric Environment variables"
                    )
                else:
                    raise ValueError(
                        f"Required environment variable '{key}' not found in Fabric Environment. "
                        f"Add to Environment artifact → Environment variables section."
                    )
            return default
        
        return value
    
    def get_secret(self, key: str, required: bool = True) -> Optional[str]:
        """Get secret variable (never logged).
        
        Same as get() but semantically marks the variable as secret.
        Used for API tokens, passwords, connection strings, etc.
        
        Args:
            key: Secret variable name
            required: Raise error if missing? (default: True)
        
        Returns:
            Secret value as string
        
        Raises:
            ValueError: If required=True and variable not found
        
        Example:
            >>> api_token = variables.get_secret("API_TOKEN")
            >>> password = variables.get_secret("DB_PASSWORD")
        """
        return self.get(key, required=required)
    
    def get_bool(self, key: str, default: bool = False) -> bool:
        """Get boolean variable.
        
        Converts string values to boolean:
        - True: "true", "1", "yes", "on" (case-insensitive)
        - False: All other values or missing
        
        Args:
            key: Variable name
            default: Default value if not found
        
        Returns:
            Boolean value
        
        Example:
            >>> debug = variables.get_bool("DEBUG_MODE", default=False)
            >>> enabled = variables.get_bool("FEATURE_ENABLED")
        """
        value = self.get(key)
        if value is None:
            return default
        return value.lower() in ("true", "1", "yes", "on")
    
    def get_int(self, key: str, default: int = 0) -> int:
        """Get integer variable.
        
        Args:
            key: Variable name
            default: Default value if not found or conversion fails
        
        Returns:
            Integer value
        
        Example:
            >>> timeout = variables.get_int("TIMEOUT_SECONDS", default=30)
            >>> retry_count = variables.get_int("MAX_RETRIES", default=3)
        """
        value = self.get(key)
        if value is None:
            return default
        
        try:
            return int(value)
        except (ValueError, TypeError):
            return default
    
    def get_float(self, key: str, default: float = 0.0) -> float:
        """Get float variable.
        
        Args:
            key: Variable name
            default: Default value if not found or conversion fails
        
        Returns:
            Float value
        
        Example:
            >>> threshold = variables.get_float("CONFIDENCE_THRESHOLD", default=0.8)
        """
        value = self.get(key)
        if value is None:
            return default
        
        try:
            return float(value)
        except (ValueError, TypeError):
            return default
    
    def list_all(self) -> dict:
        """List all variables in the library (non-secret values only).
        
        Useful for debugging and validation.
        Note: Secret values are masked with '***'.
        
        Returns:
            Dictionary of variable names to values
        
        Example:
            >>> all_vars = variables.list_all()
            >>> print(f"Available variables: {list(all_vars.keys())}")
        """
        if self._utils is None:
            return {}
        
        try:
            # This is a placeholder - actual implementation depends on
            # whether Fabric provides a list method
            # For now, return empty dict
            return {}
        except Exception:
            return {}
    
    def __repr__(self) -> str:
        """String representation for debugging."""
        return f"VariableLibrary(library='{self.library_name}')"

