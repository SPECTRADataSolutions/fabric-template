"""
SPECTRA Fabric SDK - Delta Table Operations

Simplified Delta table operations with automatic metastore registration.

Part of the SPECTRA Seven-Stage Data Platform.
"""

from typing import Optional, List
import logging


class DeltaTable:
    """Delta table operations helper.
    
    Handles:
    - Writing DataFrames to Delta format
    - Registering tables in Spark metastore
    - Automatic schema creation (requires lakehouse defaultSchema=dbo)
    - Partition management
    - Merge operations
    
    Critical Pattern:
        Tables must be explicitly registered in the metastore using
        CREATE TABLE IF NOT EXISTS ... USING DELTA LOCATION ...
        to appear in Fabric Lakehouse UI and auto-create schemas.
    
    Example:
        >>> delta = DeltaTable(spark, log)
        >>> 
        >>> # Write + register in one step
        >>> delta.write(df, "source.endpoints", "Tables/source/endpoints")
        >>> 
        >>> # Or register existing Delta table
        >>> delta.register("source.projects", "Tables/source/projects")
    """
    
    def __init__(self, spark, log: Optional[logging.Logger] = None):
        """Initialize Delta operations helper.
        
        Args:
            spark: Active SparkSession instance
            log: Logger instance (optional)
        """
        self._spark = spark
        self._log = log or logging.getLogger(__name__)
    
    def register(self, table_name: str, path: str) -> None:
        """Register existing Delta table in Spark metastore.
        
        Makes Delta tables visible and queryable in Fabric Lakehouse UI.
        Prevents "Unidentified" folder warnings.
        Auto-creates schema if lakehouse has defaultSchema=dbo configured.
        
        Idempotent: Safe to call multiple times.
        
        Args:
            table_name: Fully qualified table name (e.g., "source.endpoints")
            path: Delta table path on disk (e.g., "Tables/source/endpoints")
        
        Example:
            >>> df.write.format("delta").save("Tables/source/my_table")
            >>> delta.register("source.my_table", "Tables/source/my_table")
        
        Note:
            This is the critical pattern for Fabric Delta table management.
            Without explicit registration, tables appear as "Unidentified"
            folders in the Lakehouse UI.
        """
        self._spark.sql(
            f"CREATE TABLE IF NOT EXISTS {table_name} USING DELTA LOCATION '{path}'"
        )
        self._log.info(f"  📋 Registered: {table_name}")
    
    def write(
        self,
        df,
        table_name: str,
        path: str,
        mode: str = "overwrite",
        partition_by: Optional[List[str]] = None
    ) -> None:
        """Write DataFrame to Delta and register in metastore.
        
        One-step write + register operation.
        
        Args:
            df: DataFrame to write
            table_name: Fully qualified table name (e.g., "source.endpoints")
            path: Delta table path (e.g., "Tables/source/endpoints")
            mode: Write mode (default: "overwrite", also: "append", "ignore", "error")
            partition_by: Optional list of columns to partition by
        
        Example:
            >>> # Simple write
            >>> delta.write(df, "source.projects", "Tables/source/projects")
            >>> 
            >>> # Append with partitioning
            >>> delta.write(
            ...     df,
            ...     "source.executions",
            ...     "Tables/source/executions",
            ...     mode="append",
            ...     partition_by=["execution_date"]
            ... )
        """
        # Write DataFrame to Delta
        writer = df.write.format("delta").mode(mode)
        
        if partition_by:
            writer = writer.partitionBy(*partition_by)
        
        writer.save(path)
        
        row_count = df.count()
        self._log.info(f"  ✅ Wrote {row_count} rows to {path}")
        
        # Register in metastore
        self.register(table_name, path)
    
    def merge(
        self,
        target_table: str,
        source_df,
        merge_condition: str,
        when_matched_update: dict,
        when_not_matched_insert: dict
    ) -> None:
        """Perform Delta merge (UPSERT) operation.
        
        Args:
            target_table: Fully qualified target table name
            source_df: Source DataFrame with new/updated data
            merge_condition: SQL condition for matching rows (e.g., "target.id = source.id")
            when_matched_update: Dict of column updates (e.g., {"col": "source.col"})
            when_not_matched_insert: Dict of column inserts
        
        Example:
            >>> delta.merge(
            ...     target_table="source.projects",
            ...     source_df=df_new,
            ...     merge_condition="target.project_id = source.project_id",
            ...     when_matched_update={"updated_at": "source.updated_at"},
            ...     when_not_matched_insert={"*": "*"}  # Insert all columns
            ... )
        
        Note:
            Requires Delta Lake merge syntax support in Fabric.
        """
        # Create temp view for source
        source_df.createOrReplaceTempView("merge_source")
        
        # Build update clause
        update_clause = ", ".join(
            f"{col} = {val}" for col, val in when_matched_update.items()
        )
        
        # Build insert clause
        if when_not_matched_insert.get("*") == "*":
            insert_clause = "*"
        else:
            insert_cols = ", ".join(when_not_matched_insert.keys())
            insert_vals = ", ".join(when_not_matched_insert.values())
            insert_clause = f"({insert_cols}) VALUES ({insert_vals})"
        
        # Execute merge
        merge_sql = f"""
        MERGE INTO {target_table} AS target
        USING merge_source AS source
        ON {merge_condition}
        WHEN MATCHED THEN UPDATE SET {update_clause}
        WHEN NOT MATCHED THEN INSERT {insert_clause}
        """
        
        self._spark.sql(merge_sql)
        self._log.info(f"  🔄 Merged data into {target_table}")
    
    def vacuum(self, table_name: str, retention_hours: int = 168) -> None:
        """Vacuum Delta table to remove old files.
        
        Args:
            table_name: Fully qualified table name
            retention_hours: Retention period in hours (default: 168 = 7 days)
        
        Example:
            >>> delta.vacuum("source.executions", retention_hours=168)
        
        Note:
            Be careful with retention period. Files needed for time travel
            will be removed.
        """
        self._spark.sql(f"VACUUM {table_name} RETAIN {retention_hours} HOURS")
        self._log.info(f"  🧹 Vacuumed {table_name} (retention: {retention_hours}h)")
    
    def optimize(self, table_name: str, z_order_by: Optional[List[str]] = None) -> None:
        """Optimize Delta table (compaction and Z-ordering).
        
        Args:
            table_name: Fully qualified table name
            z_order_by: Optional list of columns for Z-ordering
        
        Example:
            >>> delta.optimize("source.executions", z_order_by=["execution_date"])
        
        Note:
            Optimizes file layout for better query performance.
        """
        optimize_sql = f"OPTIMIZE {table_name}"
        
        if z_order_by:
            z_order_cols = ", ".join(z_order_by)
            optimize_sql += f" ZORDER BY ({z_order_cols})"
        
        self._spark.sql(optimize_sql)
        self._log.info(f"  ⚡ Optimized {table_name}")
    
    def describe_history(self, table_name: str, limit: int = 10):
        """Get Delta table history (commits, operations).
        
        Args:
            table_name: Fully qualified table name
            limit: Number of history entries to return
        
        Returns:
            DataFrame with table history
        
        Example:
            >>> history = delta.describe_history("source.projects", limit=5)
            >>> history.show()
        """
        return self._spark.sql(f"DESCRIBE HISTORY {table_name} LIMIT {limit}")
    
    def __repr__(self) -> str:
        """String representation for debugging."""
        return "DeltaTable(spark)"

