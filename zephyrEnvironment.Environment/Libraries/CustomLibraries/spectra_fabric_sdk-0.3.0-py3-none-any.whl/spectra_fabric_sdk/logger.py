"""
SPECTRA Fabric SDK - SPECTRA-Grade Logger

Consistent, context-aware logging with smart debug mode.

Part of the SPECTRA Seven-Stage Data Platform.
"""

import logging
import sys
from typing import Optional


class SPECTRALogger:
    """SPECTRA-grade logger with context awareness.
    
    Features:
    - Standardized formatting (timestamp, level, message)
    - Smart debug mode (auto-enable in interactive mode)
    - Context injection (workspace, notebook, stage)
    - Structured output
    - Color support (future)
    
    Example:
        >>> logger = SPECTRALogger.create(
        ...     name="sourceZephyr",
        ...     level="INFO",
        ...     notebook_name="sourceZephyr",
        ...     workspace_id="workspace-123"
        ... )
        >>> logger.info("Processing started")
        >>> logger.debug("Detailed debug information")
    """
    
    @staticmethod
    def create(
        name: str,
        level: str = "INFO",
        notebook_name: Optional[str] = None,
        workspace_id: Optional[str] = None,
        stage: Optional[str] = None
    ) -> logging.Logger:
        """Create configured SPECTRA logger.
        
        Args:
            name: Logger name (typically notebook/module name)
            level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            notebook_name: Optional notebook name for context
            workspace_id: Optional workspace ID for context
            stage: Optional SPECTRA stage for context
        
        Returns:
            Configured logger instance
        
        Example:
            >>> log = SPECTRALogger.create(
            ...     name="sourceZephyr",
            ...     level="DEBUG",
            ...     notebook_name="sourceZephyr",
            ...     stage="source"
            ... )
        """
        # Create logger
        logger = logging.getLogger(name)
        logger.setLevel(getattr(logging, level.upper()))
        
        # Remove existing handlers
        logger.handlers.clear()
        
        # Create handler
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(getattr(logging, level.upper()))
        
        # Create formatter
        format_parts = ["%(asctime)s", "%(levelname)-8s"]
        
        # Add context if provided
        if notebook_name:
            format_parts.append(f"[{notebook_name}]")
        if stage:
            format_parts.append(f"({stage})")
        
        format_parts.append("%(message)s")
        format_string = " - ".join(format_parts)
        
        formatter = logging.Formatter(
            format_string,
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        # Prevent propagation to root logger
        logger.propagate = False
        
        return logger
    
    @staticmethod
    def get_default_level(is_interactive: bool = False, debug_override: bool = False) -> str:
        """Determine default log level based on execution context.
        
        Smart debug mode:
        - Interactive mode: DEBUG (developer is present)
        - Pipeline mode: INFO (production logging)
        - Debug override: Always DEBUG
        
        Args:
            is_interactive: Running in interactive Fabric mode?
            debug_override: Force DEBUG level?
        
        Returns:
            Log level string (DEBUG or INFO)
        
        Example:
            >>> level = SPECTRALogger.get_default_level(is_interactive=True)
            >>> # Returns "DEBUG"
        """
        if debug_override:
            return "DEBUG"
        
        if is_interactive:
            return "DEBUG"
        
        return "INFO"


# ══════════════════════════════════════════════════════════════════════════
# Convenience Functions
# ══════════════════════════════════════════════════════════════════════════

def create_logger(
    name: str,
    level: str = "INFO",
    **context
) -> logging.Logger:
    """Convenience function to create SPECTRA logger.
    
    Args:
        name: Logger name
        level: Log level
        **context: Optional context (notebook_name, workspace_id, stage)
    
    Returns:
        Configured logger
    
    Example:
        >>> log = create_logger("myNotebook", level="DEBUG", stage="source")
    """
    return SPECTRALogger.create(name, level, **context)

