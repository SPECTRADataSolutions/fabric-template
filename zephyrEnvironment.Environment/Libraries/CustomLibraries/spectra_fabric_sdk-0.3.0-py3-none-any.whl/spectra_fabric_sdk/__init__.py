"""
SPECTRA Fabric SDK

Clean, object-oriented interface to Microsoft Fabric for Notebooks.

Part of the SPECTRA Seven-Stage Data Platform.
"""

from .session import NotebookSession
from .pipeline import Pipeline
from .environment import Environment
from .variables import VariableLibrary
from .delta import DeltaTable
from .logger import SPECTRALogger, create_logger

__version__ = "1.0.0"
__all__ = [
    "NotebookSession",
    "Pipeline",
    "Environment",
    "VariableLibrary",
    "DeltaTable",
    "SPECTRALogger",
    "create_logger",
]


